# CommandLineFPS
A First Person Shooter at the command line? Yup...

Please see the source file on how to configure your command line before running.

This is designed for MS Windows
